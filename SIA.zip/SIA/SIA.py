import torch
from torch import nn
import torch.nn.functional as F
from itertools import chain

from res2net_v1b_base import Res2Net_model

from timm.models.layers import trunc_normal_
import math
import numpy as np
def get_upsampling_weight(in_channels, out_channels, kernel_size):
    """Make a 2D bilinear kernel suitable for upsampling"""
    factor = (kernel_size + 1) // 2
    if kernel_size % 2 == 1:
        center = factor - 1
    else:
        center = factor - 0.5
    og = np.ogrid[:kernel_size, :kernel_size]
    filt = (1 - abs(og[0] - center) / factor) * \
           (1 - abs(og[1] - center) / factor)
    weight = np.zeros((in_channels, out_channels, kernel_size, kernel_size),
                      dtype=np.float64)
    weight[range(in_channels), range(out_channels), :, :] = filt
    return torch.from_numpy(weight).float()
class att_sal(nn.Module):
    def __init__(self):
        super(att_sal, self).__init__()
        self.C1 = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1),
            nn.BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.Conv2d(64, 64, 3, padding=1),
            nn.BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.AvgPool2d(2, stride=2)
        )


        self.B2 = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.AvgPool2d(2, stride=2),
        )

        self.C2 = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.Conv2d(128, 128, 3, padding=1),
            nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.AvgPool2d(2, stride=2),
        )


        self.C3 = nn.Sequential(
            nn.Conv2d(128, 64, 3, padding=1),
            nn.BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.Conv2d(64, 64, 3, padding=1),
            nn.BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.AvgPool2d(2, stride=2),
        )

        self.B3 = nn.Sequential(
            nn.Conv2d(128, 64, 3, padding=1),
            nn.BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU(),
            nn.AvgPool2d(2, stride=2),
        )

        self.C4 = nn.Sequential(
            nn.Conv2d(64, 32, 3, padding=1),
            nn.BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU()
        )

        self.C5 = nn.Sequential(
            nn.Conv2d(32, 32, 3, padding=1),
            nn.BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU()
        )
        self.C6 = nn.Sequential(
            nn.Conv2d(32, 32, 3, padding=1),
            nn.BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True),
            nn.PReLU()
        )

        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
                   nn.Linear(32, 32),
                   ##nn.Dropout(p=0.3),
                   nn.ReLU(True),
                   nn.Linear(32, 32),
                   nn.Sigmoid(),
                   )

        self.pred1 = nn.Conv2d(32, 32, 1, padding=0)
        self.pred2 = nn.Conv2d(32, 3, 1, padding=0)
        self.pred3 = nn.Conv2d(3, 1, 1, padding=0)
        self.upsample = nn.Upsample(scale_factor=8, mode='bilinear', align_corners=True)

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # m.weight.data.zero_()
                nn.init.normal_(m.weight.data, std=0.01)
                if m.bias is not None:
                    m.bias.data.zero_()
            if isinstance(m, nn.ConvTranspose2d):
                assert m.kernel_size[0] == m.kernel_size[1]
                initial_weight = get_upsampling_weight(m.in_channels, m.out_channels, m.kernel_size[0])
                m.weight.data.copy_(initial_weight)

    def forward(self, images):
        C1 = self.C1(images)

        C2 = self.C2(C1)

        B2 = C2+self.B2(C1)
        C3 = self.C3(B2)

        B3 = C3 +self.B3(B2)
        C4 = self.C4(B3)

        pred_att1 = self.pred1(C4)
        pred_att2 = self.pred2(pred_att1)
        pred_att3 = self.pred3(pred_att2)
        pred_att = self.upsample(pred_att3)
        pred_att = torch.sigmoid(pred_att)

        bz = images.shape[0]
        FM = self.C5(C4)
        FM = self.C6(FM)
        rgb_gap = self.gap(FM)
        rgb_gap = rgb_gap.view(bz, -1)
        rgb_gap = self.fc(rgb_gap)
        gate = rgb_gap[:, -1].view(bz, 1, 1, 1)
        return pred_att, gate.view(bz, -1), gate
class CrossAttention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None):
        super(CrossAttention, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.kv1 = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.kv2 = nn.Linear(dim, dim * 2, bias=qkv_bias)

    def forward(self, x1, x2):
        B, N, C = x1.shape
        q1 = x1.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        q2 = x2.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        k1, v1 = self.kv1(x1).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()
        k2, v2 = self.kv2(x2).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous()

        ctx1 = (k1.transpose(-2, -1) @ v1) * self.scale
        ctx1 = ctx1.softmax(dim=-2)
        ctx2 = (k2.transpose(-2, -1) @ v2) * self.scale
        ctx2 = ctx2.softmax(dim=-2)

        x1 = (q1 @ ctx2).permute(0, 2, 1, 3).reshape(B, N, C).contiguous()
        x2 = (q2 @ ctx1).permute(0, 2, 1, 3).reshape(B, N, C).contiguous()

        return x1, x2
class CrossPath(nn.Module):
    def __init__(self, dim, reduction=1, num_heads=None, norm_layer=nn.LayerNorm):
        super().__init__()
        self.channel_proj1 = nn.Linear(dim, dim // reduction * 2)
        self.channel_proj2 = nn.Linear(dim, dim // reduction * 2)
        self.act1 = nn.ReLU(inplace=True)
        self.act2 = nn.ReLU(inplace=True)
        self.cross_attn = CrossAttention(dim // reduction, num_heads=num_heads)
        self.end_proj1 = nn.Linear(dim // reduction * 2, dim)
        self.end_proj2 = nn.Linear(dim // reduction * 2, dim)
        self.norm1 = norm_layer(dim)
        self.norm2 = norm_layer(dim)

    def forward(self, x1, x2):
        y1, u1 = self.act1(self.channel_proj1(x1)).chunk(2, dim=-1)
        y2, u2 = self.act2(self.channel_proj2(x2)).chunk(2, dim=-1)
        v1, v2 = self.cross_attn(u1, u2)
        y1 = torch.cat((y1, v1), dim=-1)
        y2 = torch.cat((y2, v2), dim=-1)
        out_x1 = self.norm1(x1 + self.end_proj1(y1))
        out_x2 = self.norm2(x2 + self.end_proj2(y2))
        return out_x1, out_x2
class ChannelEmbed(nn.Module):
    def __init__(self, in_channels, out_channels, reduction=1, norm_layer=nn.BatchNorm2d):
        super(ChannelEmbed, self).__init__()
        self.out_channels = out_channels
        self.residual = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.channel_embed = nn.Sequential(
            nn.Conv2d(in_channels, out_channels // reduction, kernel_size=1, bias=True),
            nn.Conv2d(out_channels // reduction, out_channels // reduction, kernel_size=3, stride=1, padding=1,
                      bias=True, groups=out_channels // reduction),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels // reduction, out_channels, kernel_size=1, bias=True),
            norm_layer(out_channels)
        )
        self.norm = norm_layer(out_channels)

    def forward(self, x, H, W):
        B, N, _C = x.shape
        x = x.permute(0, 2, 1).reshape(B, _C, H, W).contiguous()
        residual = self.residual(x)
        x = self.channel_embed(x)
        out = self.norm(residual + x)
        return out
class IPFM(nn.Module):
    def __init__(self, dim, reduction=1, num_heads=None, norm_layer=nn.BatchNorm2d):
        super().__init__()
        self.cross = CrossPath(dim=dim, reduction=reduction, num_heads=num_heads)
        self.channel_emb = ChannelEmbed(in_channels=dim * 2, out_channels=dim, reduction=reduction,
                                        norm_layer=norm_layer)
        self.apply(self._init_weights)
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x1, x2):
        B, C, H, W = x1.shape
        x1 = x1.flatten(2).transpose(1, 2)
        x2 = x2.flatten(2).transpose(1, 2)
        x1, x2 = self.cross(x1, x2)
        x1 = x1.permute(0, 2, 1).reshape(B, C, H, W).contiguous()
        x2 = x2.permute(0, 2, 1).reshape(B, C, H, W).contiguous()
        return x1, x2

def convblock(in_, out_, ks, st, pad):
    return nn.Sequential(
        nn.Conv2d(in_, out_, ks, st, pad),
        nn.BatchNorm2d(out_),
        nn.ReLU(inplace=True)
    )

class QM1(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(QM1, self).__init__()
        self.ch2 = ch_2
        self.ca1 = CA(ch_1)

        self.FAM = IPFM(ch_2, num_heads=4)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre, s, gate):
        cur_size = e_r.size()[2:]
        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))
        e_r, e_t = self.FAM(e_r, e_t)
        fus = pre + gate*s*e_r + (1-gate)*e_t
        fus = pre + self.conv_fuse(fus)
        return fus

class QM2(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(QM2, self).__init__()
        self.ch2 = ch_2
        self.ca1 = CA(ch_1)

        self.FAM =IPFM(ch_2, num_heads=4)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre, s, gate):
        cur_size = e_r.size()[2:]
        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))
        e_r, e_t = self.FAM(e_r, e_t)
        fus = pre + gate*s*e_r + (1-gate)*e_t
        fus = pre + self.conv_fuse(fus)

        return fus
class QM3(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(QM3, self).__init__()
        self.ch2 = ch_2
        self.ca1 = CA(ch_1)
        self.FAM = IPFM(ch_2, num_heads=4)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre, s, gate):
        cur_size = e_r.size()[2:]
        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))
        e_r, e_t = self.FAM(e_r, e_t)
        fus = pre + gate*s*e_r + (1-gate)*e_t
        fus = pre + self.conv_fuse(fus)

        return fus
class QM4(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(QM4, self).__init__()
        self.ch2 = ch_2
        self.ca1 = CA(ch_1)

        self.FAM = IPFM(ch_2, num_heads=8)
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, pre, s, gate):
        cur_size = e_r.size()[2:]

        pre = self.ca1(pre)
        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))

        e_r, e_t = self.FAM(e_r, e_t)
        fus = pre + gate*s*e_r + (1-gate)*e_t
        fus = pre + self.conv_fuse(fus)

        return fus

class QM5(nn.Module):
    def __init__(self, ch_1, ch_2):  # ch_1:previous, ch_2:current/output
        super(QM5, self).__init__()

        self.ch2 = ch_2

        self.FAM =IPFM(ch_2, num_heads=8)
        self.conv_fuse = nn.Sequential(
            nn.Conv2d(ch_2, ch_2 // 4, 3, 1, 1),
            nn.BatchNorm2d(ch_2 // 4),
            nn.ReLU(),
            nn.Conv2d(ch_2 // 4, ch_2, 3, 1, 1),
            nn.BatchNorm2d(ch_2),
            nn.ReLU()
        )

    def forward(self, e_r, e_t, s, gate):
        e_r, e_t = self.FAM(e_r, e_t)
        fus = gate*s*e_r + (1-gate)*e_t
        fus = self.conv_fuse(fus)
        return fus


class GlobalInfo(nn.Module):  # ASPP

    def __init__(self):  # dim = 512*2  in_dim = 512  down_dim = 128
        super(GlobalInfo, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=2, padding=2), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=4, padding=4), nn.BatchNorm2d(128), nn.PReLU()
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=3, dilation=6, padding=6), nn.BatchNorm2d(128), nn.PReLU()
         )
        self.conv5 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1), nn.BatchNorm2d(128),  nn.PReLU()
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(5 * 128, 512, kernel_size=1), nn.BatchNorm2d(512), nn.PReLU()
        )

    def forward(self, x):

        conv1 = self.conv1(x)
        conv2 = self.conv2(x)
        conv3 = self.conv3(x)
        conv4 = self.conv4(x)
        conv5 = F.upsample(self.conv5(F.adaptive_avg_pool2d(x, 1)), size=x.size()[2:], mode='bilinear')

        x_fuse = self.fuse(torch.cat((conv1, conv2, conv3, conv4, conv5), 1))

        return x_fuse


class CA(nn.Module):
    def __init__(self, in_ch):
        super(CA, self).__init__()
        self.avg_weight = nn.AdaptiveAvgPool2d(1)
        self.max_weight = nn.AdaptiveMaxPool2d(1)
        self.fus = nn.Sequential(
            nn.Conv2d(in_ch, in_ch // 2, 1, 1, 0),
            nn.ReLU(),
            nn.Conv2d(in_ch // 2, in_ch, 1, 1, 0),
        )
        self.c_mask = nn.Sigmoid()

    def forward(self, x):
        avg_map_c = self.avg_weight(x)
        max_map_c = self.max_weight(x)
        c_mask = self.c_mask(torch.add(self.fus(avg_map_c), self.fus(max_map_c)))
        return torch.mul(x, c_mask)

class gate(nn.Module):
    def __init__(self, in_ch):
        super(gate, self).__init__()
        self.gap1 = nn.AdaptiveAvgPool2d(1)
        self.gap2 = nn.AdaptiveAvgPool2d(1)
        self.linear1 = nn.Linear(in_ch*2, in_ch*2)
        self.drop = nn.Dropout(p=0.3)
        self.relu = nn.ReLU(True)
        self.linear2 = nn.Linear(in_ch*2, in_ch+1)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x, y):
        bz, c, h, w = x.shape
        x_gap = self.gap1(x)
        x_gap = x_gap.view(bz, -1)
        y_gap = self.gap2(y)
        y_gap = y_gap.view(bz, -1)
        feat = torch.cat((x_gap, y_gap), dim=1)
        feat = self.linear1(feat)
        feat = self.drop(feat)
        feat = self.relu(feat)
        feat = self.linear2(feat)
        feat = self.sigmoid(feat)
        gate = feat[:, -1].view(bz, 1, 1, 1)
        return gate

class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()

        self.rgb_global = GlobalInfo()
        self.t_global = GlobalInfo()
        self.gate = gate(512)
        self.d5 = QM5(512, 512)
        self.d4 = QM4(512, 512)
        self.d3 = QM3(512, 256)
        self.d2 = QM2(256, 128)
        self.d1 = QM1(128, 64)


        self.score_1 = nn.Conv2d(64, 1, 1, 1, 0)
        self.score_2 = nn.Conv2d(128, 1, 1, 1, 0)
        self.score_3 = nn.Conv2d(256, 1, 1, 1, 0)
        self.score_4 = nn.Conv2d(512, 1, 1, 1, 0)
        self.score_5 = nn.Conv2d(512, 1, 1, 1, 0)

    def forward(self, rgb, t, s):
        xsize = rgb[0].size()[2:]
        rgb_global = self.rgb_global(rgb[4])
        t_global = self.t_global(t[4])
        gate = self.gate(rgb_global, t_global)

        d5 = self.d5(rgb_global, t_global, s, gate)
        d4 = self.d4(rgb[3], t[3], d5, s, gate)
        d3 = self.d3(rgb[2], t[2], d4, s, gate)
        d2 = self.d2(rgb[1], t[1], d3, s, gate)
        d1 = self.d1(rgb[0], t[0], d2, s, gate)

        score1 = self.score_1(d1)
        score2 = self.score_2(d2)
        score3 = self.score_3(d3)
        score4 = self.score_4(d4)
        score5 = self.score_5(d5)
        s1  = F.interpolate(score1, xsize, mode='bilinear', align_corners=True)
        s2  = F.interpolate(score2, xsize, mode='bilinear', align_corners=True)
        s3  = F.interpolate(score3, xsize, mode='bilinear', align_corners=True)
        score0 = s1 + s2 + s3

        return score1, score2, score3, score4, score5, score0


def upsample(x, size):
    return F.interpolate(x, size, mode='bilinear', align_corners=True)

class SIA(nn.Module):
    def __init__(self, train=False):
        super(SIA, self).__init__()
        self.att_sal = att_sal()

        self.rgb_net = Res2Net_model(50)
        self.t_net = Res2Net_model(50)

        trans_layers_mapping = [[256, 128], [512, 256], [1024, 512], [2048, 512]]
        self.trans_rgb = nn.ModuleList()
        self.trans_t = nn.ModuleList()
        self.sigmoid = nn.Sigmoid()
        for mapp in trans_layers_mapping:
            self.trans_rgb.append(convblock(mapp[0], mapp[1], 1, 1, 0))
            self.trans_t.append(convblock(mapp[0], mapp[1], 1, 1, 0))
        self.decoder = Decoder()

        for m in chain(self.decoder.modules(), chain(self.trans_rgb.modules(), self.trans_t.modules())):
            if isinstance(m, nn.Conv2d):
                m.weight.data.normal_(0, 0.01)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, rgb, t):
        rgb_f = []
        rgbi = []
        t_f = []
        gate, _, s = self.att_sal(rgb)
        g1 = F.interpolate(gate, [176, 176], mode='bilinear', align_corners=True)
        g2 = F.interpolate(gate, [88, 88], mode='bilinear', align_corners=True)
        x = self.rgb_net.relu(self.rgb_net.bn1(self.rgb_net.conv1(rgb)))
        rgb_f.append(x)  # 64
        rgbi.append(x)
        x = self.rgb_net.layer1(self.rgb_net.maxpool(x))
        rgbi.append(x)
        rgb_f.append(self.trans_rgb[0](x))  # 256->128
        x = self.rgb_net.layer2(x)  # 256->512
        rgbi.append(x)
        rgb_f.append(self.trans_rgb[1](x))  # 512->256
        x = self.rgb_net.layer3(x)  # 512->1024
        rgbi.append(x)
        rgb_f.append(self.trans_rgb[2](x))  # 1024->512
        x = self.rgb_net.layer4(x)  # 1024->2048
        rgbi.append(x)
        rgb_f.append(self.trans_rgb[3](x))  # 2048->512

        x = self.t_net.relu(self.t_net.bn1(self.t_net.conv1(t)))
        t_f.append(x)  # 64
        x = self.t_net.layer1(self.t_net.maxpool(x + g1*rgbi[0]))
        t_f.append(self.trans_t[0](x))  # 256->128
        x = self.t_net.layer2(x+g2*rgbi[1])  # 256->512
        t_f.append(self.trans_t[1](x))  # 512->256
        x = self.t_net.layer3(x+rgbi[2])  # 512->1024
        t_f.append(self.trans_t[2](x))  # 1024->512
        x = self.t_net.layer4(x+rgbi[3])  # 1024->2048
        t_f.append(self.trans_t[3](x+rgbi[4]))  # 2048->512


        score1, score2, score3, score4, score5, score0 = self.decoder(rgb_f, t_f, s)
        return score1, score2, score3, score4, score5, score0, self.sigmoid(score1), self.sigmoid(score2), self.sigmoid(score3), self.sigmoid(score4), self.sigmoid(score5), gate
